export interface Customer {
    id?: number;
    firstName?: string;
    lastName?: string;
    phoneNum?: string;
    emailID?: string;
    password?: string;
    createdOn?: Date;
    activeYN?: string;
}
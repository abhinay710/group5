export interface Login {
    emailID?: string;
    password?: string;
    designation?:string;
}
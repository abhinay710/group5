export interface Util {
    isHovered?: boolean; 
}
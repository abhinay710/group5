
export interface Dessert {
    id?: number;
    name?: string;
    glutenFreeYN?: string;
    sugarFreeYN?: string;
    price?: number;
    calories?: number;
    timeToPrepare?: string;
}